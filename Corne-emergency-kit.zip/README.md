# Corne 비상용 단독 모드

동글이 없을 때만 쓰는 수동 전환 방식이다. 자동 fallback은 지원하지 않는다. 이 타깃은 기존 공통 50-position 키맵과 동일한 왼쪽 Corne 배선을 사용하며, 왼쪽이 BLE/USB 중심 장치가 된다. 오른쪽은 기존 corne_right_peripheral 펌웨어를 사용한다. 동글용 빌드는 변경하지 않는다.

## 파일

- 왼쪽 단독 중심: corne_left_standalone_CENTRAL.uf2
- 오른쪽 주변기기: corne_right_peripheral.uf2
- 설정 초기화: nice_nano_settings_reset.uf2
- 동글 복귀용 왼쪽: corne_left_peripheral.uf2

## 비상용 단독으로 전환

중심 장치가 바뀌므로 ZMK는 양쪽 설정 초기화와 재페어링을 권장한다. 초기화하면 저장된 BLE 페어링 등 설정이 지워진다. 전환 전에 동글을 끄고 Cornix 등 다른 주변기기도 꺼서 엉뚱한 조합으로 연결되지 않게 한다.

1. 양쪽 Corne을 부트로더로 진입시킨 뒤 각 반쪽에 nice_nano_settings_reset.uf2를 각각 플래시한다. 초기화 펌웨어는 일반 키보드가 아니다.
2. 왼쪽에 corne_left_standalone_CENTRAL.uf2, 오른쪽에 corne_right_peripheral.uf2를 넣는다.
3. 양쪽을 비슷한 시각에 재시작하고 연결을 확인한다. 왼쪽을 USB 또는 Bluetooth로 호스트에 연결한다. 기존 호스트 연결 기록이 충돌하면 해당 항목을 지우고 새로 페어링한다.
4. 좌우 키, 레이어, 블루투스와 USB 기능을 실물에서 확인한다.

## 동글 모드로 복귀

동글 및 다른 키보드 전원을 끄고 Corne 양쪽과 동글의 이전 split bond를 초기화한 다음, 왼쪽 corne_left_peripheral.uf2, 오른쪽 corne_right_peripheral.uf2, 동글에 원래 사용한 동글 UF2를 각각 넣고 다시 페어링한다. 동글 설정 초기화는 저장된 호스트 프로필 및 Cornix 연결 정보도 지울 수 있으므로 호스트와 Cornix까지 다시 연결해야 할 수 있다. 전환은 플래시와 재페어링이 필요한 복구 절차이지 즉시 전환되는 기능이 아니다.

펌웨어 빌드 성공이 실물 작동을 보장하지 않는다. 원래 Corne/Cornix 저장소는 건드리지 않는다.
